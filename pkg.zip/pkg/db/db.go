package db

import (
	"database/sql"
	"os"

	_ "modernc.org/sqlite"
)

const schema = `
CREATE TABLE scheduler (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	date CHAR(8) NOT NULL DEFAULT "",
	title VARCHAR(256) NOT NULL DEFAULT "",
	comment TEXT NOT NULL DEFAULT "",
	repeat CHAR(128) NOT NULL DEFAULT ""
);

CREATE INDEX task_date ON scheduler (date)
`

var db *sql.DB

func Init(dbFile string) error {
	var err error

	_, err = os.Stat(dbFile)

	var install bool
	if err != nil {
		install = true
	}

	db, err = sql.Open("sqlite", dbFile)
	if err != nil {
		return err
	}
	// defer db.Close()

	if install != true {
		return nil
	}

	_, err = db.Exec(schema)
	if err != nil {
		return err
	}

	return nil
}
